/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Defube to 1 to gather statistical information about operator and unique
   node caching (for debugging). */
#undef CACHESTATS

/* BuDDy's major version. */
#define MAJOR_VERSION 2

/* BuDDy's minor version. */
#define MINOR_VERSION 4

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.4"

/* Define to 1 to count number of fundamental variable swaps (for debugging).
   */
#undef SWAPCOUNT

// STATISTICS: buddy-any
